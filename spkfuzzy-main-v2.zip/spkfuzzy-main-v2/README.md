## SPK Fuzzy
