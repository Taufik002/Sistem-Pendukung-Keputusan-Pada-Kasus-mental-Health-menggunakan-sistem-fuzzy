<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Fuzzy extends CI_Controller
{
	// Teks lengkap untuk setiap pertanyaan
	private $questions = [
		"Anda merasa mudah cemas atau gugup tanpa alasan yang jelas?",
		"Seberapa sering Anda merasa tidak berenergi meskipun tidak melakukan aktivitas berat?",
		"Anda sering merasa sulit menikmati hal-hal yang sebelumnya Anda nikmati?",
		"Seberapa sering Anda merasa kesulitan untuk tidur atau tetap tertidur sepanjang malam?",
		"Anda merasa sulit untuk fokus atau berkonsentrasi pada tugas sehari-hari?",
		"Seberapa sering Anda merasa sedih atau putus asa tanpa alasan yang jelas?",
		"Anda merasa gugup saat berada di situasi sosial tertentu?",
		"Seberapa sering Anda merasa kehilangan kendali atas pikiran atau perasaan Anda?",
		"Anda merasa sulit membuat keputusan, bahkan untuk hal-hal kecil?",
		"Seberapa sering Anda merasa bahwa Anda tidak cukup baik atau merasa rendah diri?",
		"Anda merasa khawatir berlebihan tentang masa depan?",
		"Seberapa sering Anda merasa tidak termotivasi untuk bangun dari tempat tidur atau memulai hari?",
		"Anda merasa kesepian meskipun berada di sekitar orang lain?",
		"Seberapa sering Anda merasa pikiran negatif terus-menerus mengganggu Anda?",
		"Anda pernah merasa lebih baik jika Anda tidak ada (pikiran mengakhiri hidup)?",
	];

	public function index()
	{
		$this->load->view('index');
	}
	public function landingpage()
	{
		$this->load->view('index');
	}

	public function landingpagef()
	{
		$data['questions'] = $this->questions;

		$this->load->view('indexFuzzy', $data);
	}

	// Proses perhitungan fuzzy
	public function process()
	{
		$scores = $this->input->post('scores');

		if (count($scores) != 15) {
			$data['error'] = "Harus ada tepat 15 skor.";
			$data['questions'] = $this->questions;
			$this->load->view('indexFuzzy', $data);
		}

		$totalScore = array_sum($scores);

		// Peringatan untuk pertanyaan terakhir
		$specialWarning = ($scores[14] >= 3)
			? "Peringatan! Segera berikan dukungan!"
			: "TIDAK ADA";

		// Menentukan kategori
		$gejalaCategory = $this->calculateCategory($totalScore);

		// Kirim data ke view
		$data = [
			'scores' => $scores,
			'totalScore' => $totalScore,
			'gejalaCategory' => $gejalaCategory,
			'specialWarning' => $specialWarning,
			'questions' => $this->questions,
		];

		$this->load->view('indexFuzzy', $data);
	}

	// Hitung kategori gejala berdasarkan total skor
	private function calculateCategory($totalScore)
	{
		if ($totalScore <= 15) {
			return "Tidak ada gejala signifikan";
		} elseif ($totalScore <= 30) {
			return "Gejala ringan - perlu penanganan segera";
		} elseif ($totalScore <= 45) {
			return "Gejala sedang - perlu penanganan segera";
		} elseif ($totalScore <= 60) {
			return "Gejala berat - memerlukan penanganan psikolog/psikiater";
		}
		return "Skor tidak valid";
	}
}
