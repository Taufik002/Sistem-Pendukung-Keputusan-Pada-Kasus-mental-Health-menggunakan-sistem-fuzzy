<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>
	<link rel="stylesheet" href="<?php echo base_url(); ?>/assets/main.css">
	<link rel="stylesheet" href="<?php echo base_url(); ?>/assets/output.css">

	<link rel="icon" href="<?php echo base_url(); ?>/assets/favicon-32x32.png">

	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
</head>

<body>
	<div class="bg-white min-h-svh ">
		<header class="absolute inset-x-0 top-0 z-50">
			<nav class="flex items-center justify-between p-6 lg:px-8" aria-label="Global">
				<div class="flex lg:flex-1 gap-3">
					<a href="#" class="-m-1.5 p-1.5">
						<img class="h-12 w-auto" src="<?php echo base_url(); ?>assets/android-chrome-192x192.png" alt="" />
					</a>
					<div class="flex flex-col justify-center">
						<p class=" font-bold">Politeknik Negeri Jakarta</p>
						<p class="text-xs font-semibold">Bangkit, Adaptif dan Terus Melaju</p>
					</div>
				</div>
				<div class="flex lg:hidden">
					<button type="button"
						class="-m-2.5 inline-flex items-center justify-center rounded-md p-2.5 text-gray-700">
						<span class="sr-only">Open main menu</span>
						<Bars3Icon class="h-6 w-6" aria-hidden="true" />
					</button>
				</div>
				<div class="hidden lg:flex lg:gap-x-12">
					<a href="#"
						class="text-sm font-semibold leading-6 text-gray-900"></a>
				</div>
				<!-- <div class="hidden lg:flex lg:flex-1 lg:justify-end">
					<a href="#" class="text-sm font-semibold leading-6 text-gray-900">Log in
						<span aria-hidden="true">&rarr;</span></a>
				</div> -->
			</nav>

		</header>

		<div class="relative isolate px-6 lg:px-8">
			<div class="flex" id="jumbotron">
				<div class="font-quicksand">
					<h1 class="text-4xl font-semibold tracking-tight text-gray-700 ">
						Sistem Pendukung Keputusan
					</h1>
					<p class="text-6xl font-bold tracking-tight text-[#008797] ">
						Mental Health Remaja</span>
					</p>
					<p class="text-2xl tracking-tight text-[#008797] ">
						Metode Fuzzy</span>
					</p>
					<div class="mt-10" id="btn-daftar">
						<a href="<?= base_url('fuzzy') ?>"
							class="rounded-3xl bg-gradient-to-tr from-[#008797] to-[#012a2e] px-3.5 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-indigo-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600">
							Cek Mental Health Sekarang →</a>
					</div>
				</div>
				<!-- <div>
					<video autoplay muted controls loop
						id="jumbotronVideo"
						class="w-1/2 rounded-lg right-0 z-20 absolute block">
						<source src="<?php echo base_url(); ?>/assets/landingPage.mp4" type="video/mp4" />
						Your browser does not support the video tag.
					</video>
				</div> -->
			</div>

			<div class="absolute inset-x-0 top-[-100px] -z-10 transform-gpu overflow-hidden blur-3xl"
				aria-hidden="true">
				<div class="relative left-[calc(50%+3rem)] aspect-[1155/678] w-[36.125rem] -translate-x-1/2 bg-gradient-to-tr from-[#008797] to-[#1a737b] opacity-30 sm:left-[calc(50%+36rem)] sm:w-[72.1875rem]"
					style="clip-path: polygon(74.1% 44.1%, 100% 61.6%, 97.5% 26.9%, 85.5% 0.1%, 80.7% 2%, 72.5% 32.5%, 60.2% 62.4%, 52.4% 68.1%, 47.5% 58.3%, 45.2% 34.5%, 27.5% 76.7%, 0.1% 64.9%, 17.9% 100%, 27.6% 76.8%, 76.1% 97.7%, 74.1% 44.1%)" />
			</div>
		</div>
	</div>



	<script>
		const contentTopPadding = 0;
		const contentTopVideoPadding = 0;

		const bodyHeight = $('body').outerHeight(true);
		const btnDaftarHeight = $('#btn-daftar').outerHeight(true);
		$('#jumbotron').css('paddingTop', bodyHeight * 0.5 - btnDaftarHeight)

		const videoHeight = $('video').outerHeight(true);
		// console.log(videoHeight);

		$('#jumbotronVideo').css('top', bodyHeight * 0.5 - videoHeight * 0.5)
	</script>
</body>

</html>
