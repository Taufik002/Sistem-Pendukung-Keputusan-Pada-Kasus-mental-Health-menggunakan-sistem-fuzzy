<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>

	<link rel="icon" href="<?php echo base_url(); ?>/assets/favicon-32x32.png">
	<link rel="stylesheet" href="<?php echo base_url(); ?>/assets/main.css">
	<link rel="stylesheet" href="<?php echo base_url(); ?>/assets/output.css">

	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
</head>

<body>
	<div class="bg-white min-h-svh ">
		<header class="inset-x-0 top-0 z-50 relative">
			<nav class="flex items-center justify-between p-6 lg:px-8" aria-label="Global">
				<div class="flex lg:flex-1 gap-3">
					<a href="#" class="-m-1.5 p-1.5">
						<img class="h-12 w-auto" src="<?php echo base_url(); ?>assets/android-chrome-192x192.png" alt="" />
					</a>
					<div class="flex flex-col justify-center">
						<p class=" font-bold">Politeknik Negeri Jakarta</p>
						<p class="text-xs font-semibold">Bangkit, Adaptif dan Terus Melaju</p>
					</div>
				</div>
				<div class="flex lg:hidden">
					<button type="button"
						class="-m-2.5 inline-flex items-center justify-center rounded-md p-2.5 text-gray-700">
						<span class="sr-only">Open main menu</span>
						<Bars3Icon class="h-6 w-6" aria-hidden="true" />
					</button>
				</div>
				<div class="hidden lg:flex lg:gap-x-12">
					<a href="#"
						class="text-sm font-semibold leading-6 text-gray-900"></a>
				</div>
			</nav>
		</header>

		<div class="relative isolate px-6 lg:px-8">
			<div class="max-w-[50%]">
				<h1 class="text-4xl font-semibold">Penilaian Gejala</h1>
				<h2 class="text-sm font-thin">
					Form berikut untuk merupakan cara untuk mengidentifikasi kondisi mental health anda.
					Hasil dari rekomendasi mental health anda merupakan hasil dari metode fuzzy yang dikembangkan melalui
					penelitian ini.
				</h2>
				<?php if (isset($error)): ?>
					<div class="alert alert-danger"><?= $error; ?></div>
				<?php endif; ?>
			</div>

			<div class="flex mt-2" id="jumbotron">
				<div class="font-quicksand">
					<form method="POST" action="<?= base_url('fuzzy/process') ?>"
						class="w-full max-w-lg mx-auto p-6 bg-white rounded-lg shadow-md">
						<?php foreach ($questions as $index => $question): ?>
							<div class="mb-6">
								<label for="score<?= $index ?>" class="block text-lg font-medium text-gray-700">
									<?= ($index + 1) . ". " . $question; ?>
								</label>
								<select name="scores[]" id="score<?= $index ?>" class="mt-2 block w-full p-3 border border-gray-300 rounded-md text-gray-900 focus:ring-blue-500 focus:border-blue-500" required>
									<?php for ($i = 0; $i <= 4; $i++): ?>
										<option value="<?= $i ?>" <?= (isset($scores) && $scores[$index] == $i) ? 'selected' : ''; ?>>
											<?= $i ?>
										</option>
									<?php endfor; ?>
								</select>
							</div>
						<?php endforeach; ?>

						<button type="submit" class="w-full bg-blue-500 hover:bg-blue-600 text-white font-bold py-3 rounded-lg shadow transition duration-200">
							Proses
						</button>
					</form>

				</div>

				<div class="w-full max-w-lg mx-auto  ">
					<?php if (isset($totalScore)): ?>
						<div class="bg-white p-6 shadow-md rounded-lg">
							<h2 class="text-3xl font-semibold">Hasil Analisis</h2>
							<p><strong>Total Skor:</strong> <?= $totalScore; ?></p>
							<p><strong>Kategori Gejala:</strong> <?= $gejalaCategory; ?></p>
							<p><strong>Peringatan Khusus:</strong> <?= $specialWarning; ?></p>

							<a href="<?= base_url('fuzzy/landingpagef') ?>" class="w-full flex justify-center mt-2 bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 rounded-lg shadow transition duration-200">
								Uji Kembali
							</a>
						</div>
					<?php endif; ?>
				</div>
			</div>

			<div class="absolute inset-x-0 top-[-100px] -z-10 transform-gpu overflow-hidden blur-3xl"
				aria-hidden="true">
				<div class="relative left-[calc(50%+3rem)] aspect-[1155/678] w-[36.125rem] -translate-x-1/2 bg-gradient-to-tr from-[#008797] to-[#1a737b] opacity-30 sm:left-[calc(50%+36rem)] sm:w-[72.1875rem]"
					style="clip-path: polygon(74.1% 44.1%, 100% 61.6%, 97.5% 26.9%, 85.5% 0.1%, 80.7% 2%, 72.5% 32.5%, 60.2% 62.4%, 52.4% 68.1%, 47.5% 58.3%, 45.2% 34.5%, 27.5% 76.7%, 0.1% 64.9%, 17.9% 100%, 27.6% 76.8%, 76.1% 97.7%, 74.1% 44.1%)" />
			</div>
		</div>
	</div>



	<script>
		const contentTopPadding = 0;
		const contentTopVideoPadding = 0;

		const bodyHeight = $('body').outerHeight(true);
		const btnDaftarHeight = $('#btn-daftar').outerHeight(true);
		$('#jumbotron').css('paddingTop', bodyHeight * 0.5 - btnDaftarHeight)

		const videoHeight = $('video').outerHeight(true);
		// console.log(videoHeight);

		$('#jumbotronVideo').css('top', bodyHeight * 0.5 - videoHeight * 0.5)
	</script>
</body>

</html>
