/** @type {import('tailwindcss').Config} */
module.exports = {
	content: [
		"./application/views/*.{php,html}",
		"./application/views/**/*.{php,html}",
	],
	theme: {
		extend: {},
	},
	plugins: [],
};
